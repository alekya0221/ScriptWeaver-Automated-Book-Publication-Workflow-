#!/bin/bash

# Activate your conda environment (adjust name if needed)
source ~/miniconda3/etc/profile.d/conda.sh
conda activate softnerve_env

# Set OpenAI API key if not already exported (optional)
export OPENAI_API_KEY="sk-..."  # replace with actual key or load from .env

# Optional: Suppress ONNX Runtime thread affinity warnings
export ORT_DISABLE_THREAD_AFFINITY=1

# Start pipeline and filter ONNX warnings from stderr
python -m Interface.main 2> >(grep -v "pthread_setaffinity_np")
