import os
import csv
from datetime import datetime
from zoneinfo import ZoneInfo
from Save_Screenshot import log_message
from .VersionTracker import get_next_version_id

FINAL_SAVE_DIR = "logs/final_text"
os.makedirs(FINAL_SAVE_DIR, exist_ok=True)

def save_final_version(text: str, chapter_num: int, source: str = "AI") -> str:
    """
    Saves the final version of the chapter with a clean versioning scheme.
    
    Parameters:
        text (str): Final text to save (human-edited or not).
        chapter_num (int): Logical chapter number from the book.
        source (str): 'AI' or 'human' depending on whether manual edits were made.

    Returns:
        version_id (str): The saved version identifier (e.g., 'chapter01_v2').
    """

    # Timezone-aware timestamps
    now_utc = datetime.now(ZoneInfo("UTC"))
    now_ist = now_utc.astimezone(ZoneInfo("Asia/Kolkata"))

    timestamp_ist = now_ist.strftime("%Y-%m-%d %H:%M:%S")
    timestamp_utc = now_utc.strftime("%Y-%m-%d %H:%M:%S")
    version_id = get_next_version_id(chapter_num)  # e.g. chapter01_v2
    filename = os.path.join(FINAL_SAVE_DIR, f"{version_id}.txt")

    # Write version metadata and content
    with open(filename, "w", encoding="utf-8") as f:
        f.write(f"# Chapter: {chapter_num}\n")
        f.write(f"# Version: {version_id.split('_v')[-1]}\n")
        f.write(f"# Source: {source}\n")
        f.write(f"# Timestamp (IST): {timestamp_ist}\n")
        f.write(f"# Timestamp (UTC): {timestamp_utc}\n")
        f.write(f"# Filename: {os.path.basename(filename)}\n\n")
        f.write(text)

    # Append to version_manifest.csv
    manifest_path = os.path.join(FINAL_SAVE_DIR, "version_manifest.csv")
    file_exists = os.path.exists(manifest_path)

    with open(manifest_path, mode="a", newline="", encoding="utf-8") as csvfile:
        writer = csv.writer(csvfile)

        if not file_exists:
            writer.writerow(["chapter", "version", "source", "timestamp_ist", "timestamp_utc", "filename"])

        writer.writerow([
            chapter_num,
            version_id.split('_v')[-1],
            source,
            timestamp_ist,
            timestamp_utc,
            os.path.basename(filename)
        ])

    log_message(f"Final version saved as: {version_id} (source: {source}) [IST: {timestamp_ist}, UTC: {timestamp_utc}]", level="INFO")

    return version_id
