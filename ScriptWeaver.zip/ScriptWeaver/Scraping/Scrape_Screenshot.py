from playwright.sync_api import sync_playwright
from Save_Screenshot import save_text_to_file, timestamped_filename, log_message
import os

ASSET_DIR = "assets"

def scrape_chapter(url: str) -> str:
    log_message(f"Opening page: {url}", level="INFO")

    try:
        with sync_playwright() as p:
            browser = p.chromium.launch(headless=True)
            context = browser.new_context()
            page = context.new_page()
            page.goto(url)

            page.wait_for_timeout(2000)

            os.makedirs(ASSET_DIR, exist_ok=True)
            screenshot_path = os.path.join(ASSET_DIR, "chapter1_reference.png")
            page.screenshot(path=screenshot_path, full_page=True)
            log_message(f"Screenshot saved at: {screenshot_path}", level="INFO")

            content = page.inner_text("body")
            log_message("Page text content extracted.", level="INFO")

            filename = timestamped_filename("raw_chapter")
            save_text_to_file(content, filename, folder="logs/raw_text")

            browser.close()
            return content

    except Exception as e:
        log_message(f"Scraping failed: {str(e)}", level="ERROR")
        return ""
