import os
import re
from pathlib import Path

FINAL_DIR = Path("logs/final_text")

def get_latest_version(chapter_num: int) -> int:
    """
    Returns the highest version number saved for the given chapter.
    """
    pattern = re.compile(f"chapter{chapter_num:02d}_v(\\d+)\\.txt")

    versions = []
    for filename in os.listdir(FINAL_DIR):
        match = pattern.match(filename)
        if match:
            versions.append(int(match.group(1)))

    return max(versions) if versions else 0

def get_next_version_id(chapter_num: int) -> str:
    """
    Returns the next version ID string like 'chapter01_v2'.
    """
    latest = get_latest_version(chapter_num)
    return f"chapter{chapter_num:02d}_v{latest + 1}"
