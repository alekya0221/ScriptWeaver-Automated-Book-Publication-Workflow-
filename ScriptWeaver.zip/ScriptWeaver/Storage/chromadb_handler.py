import chromadb
from chromadb.config import Settings
from Save_Screenshot import log_message
from chromadb import PersistentClient
import os

# Initialize ChromaDB persistent client (new architecture)
try:
    client = PersistentClient(path="./chromadb_data")
    log_message("Initialized ChromaDB PersistentClient.", level="INFO")
except Exception as e:
    log_message(f"Failed to initialize ChromaDB client: {str(e)}", level="ERROR")
    raise  # Re-raise if you want the pipeline to stop on failure



# Collection for finalized chapters
collection = client.get_or_create_collection(name="final_versions")


# Store the final version with associated metadata
def save_version(text: str, metadata: dict) -> str:
    version_id = f"chapter_{len(collection.get()['ids']) + 1}"
    collection.add(
        documents=[text],
        ids=[version_id],
        metadatas=[metadata]
    )
    #client.persist()
    log_message(f"Version saved with ID: {version_id}", level="INFO")
    return version_id


# Retrieve versions based on similarity to the query
def retrieve_versions(query: str, top_k: int = 3) -> dict:
    try:
        result = collection.query(query_texts=[query], n_results=top_k)
        log_message(f"Retrieved top {top_k} version(s) for query.")
        return result
    except Exception as e:
        log_message(f"Error retrieving versions: {str(e)}", level="ERROR")
        return {"documents": [[]], "ids": [[]], "metadatas": [[]]}
