from Storage.RL_Learn import pick_best_version, record_feedback
from Save_Screenshot import log_message

def test_rl_retrieval_and_feedback():
    query = "final chapter 1"  # or we can go ahead with any stored version's metadata keyword
    result = pick_best_version(query)

    if result:
        print("Suggested version ID:", result["id"])
        print("\n--- Content Preview ---\n")
        print(result["document"][:500])  # Show partial output

        # Simulate user saying it's useful
        feedback = "y"  # Change to 'n' to simulate bad feedback
        reward = 1.0 if feedback == "y" else 0.0
        record_feedback(result["id"], reward)
        log_message(f"Simulated feedback: {feedback} => reward {reward}")
    else:
        print("No version retrieved. Check ChromaDB data or collection setup.")

if __name__ == "__main__":
    test_rl_retrieval_and_feedback()
