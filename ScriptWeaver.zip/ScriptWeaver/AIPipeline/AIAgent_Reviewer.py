import os
from openai import OpenAI
from Save_Screenshot import log_message

client = OpenAI(api_key=os.getenv("OPENAI_API_KEY"))

# Refines the draft for grammar, clarity, and tone
def refine_draft(text: str) -> str:
    log_message("Refining draft...")

    try:
        response = client.chat.completions.create(
            model="gpt-3.5-turbo",  # or "gpt-4" if you want consistency
            messages=[
                {
                    "role": "system",
                    "content": "You are a reviewer helping improve grammar, clarity, and tone while keeping the writer’s voice intact."
                },
                {
                    "role": "user",
                    "content": text
                }
            ],
            temperature=0.5,
            max_tokens=1000
        )
        reviewed = response.choices[0].message.content.strip()
        log_message("Draft refined by Reviewer Agent.", level="INFO")
        return reviewed

    except Exception as e:
        log_message(f"Error during refinement: {str(e)}", level="ERROR")
        return text  # Fallback to original
