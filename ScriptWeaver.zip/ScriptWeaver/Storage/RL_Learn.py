import random
import json
import os
from Storage.chromadb_handler import retrieve_versions
from Save_Screenshot import log_message, save_text_to_file, timestamped_filename

# Path to store rewards and version stats
REWARD_FILE = "rl_rewards.json"
OUTPUT_LOG_DIR = "logs/rl_outputs"

# Load or initialize reward data
def load_reward_data():
    if os.path.exists(REWARD_FILE):
        with open(REWARD_FILE, "r") as f:
            return json.load(f)
    else:
        return {}

def save_reward_data(data):
    with open(REWARD_FILE, "w") as f:
        json.dump(data, f, indent=2)

# Update reward for a version ID
def record_feedback(version_id: str, reward: float):
    data = load_reward_data()
    if version_id not in data:
        data[version_id] = {"total_reward": 0, "count": 0}
    data[version_id]["total_reward"] += reward
    data[version_id]["count"] += 1
    save_reward_data(data)
    log_message(f"Updated reward for {version_id} with {reward}")

# e-Greedy selection logic (formerly ε-Greedy)
def pick_best_version(query: str, epsilon: float = 0.1):
    reward_data = load_reward_data()
    results = retrieve_versions(query, top_k=5)
    ids = results.get("ids", [[]])[0]
    docs = results.get("documents", [[]])[0]

    if not ids:
        log_message("No versions found for query.")
        return None

    # Explore with probability epsilon (e.g., 10%)
    if random.random() < epsilon:
        idx = random.randint(0, len(ids) - 1)
        log_message("Exploring: Chose a random version.")
        return {"id": ids[idx], "document": docs[idx]}

    # Exploit: Choose highest avg reward
    scored = []
    for i, vid in enumerate(ids):
        stats = reward_data.get(vid, {"total_reward": 0, "count": 0})
        avg_reward = stats["total_reward"] / stats["count"] if stats["count"] > 0 else 0
        scored.append((avg_reward, i))

    scored.sort(reverse=True)
    best_idx = scored[0][1]
    log_message(f"Exploiting: Chose version {ids[best_idx]} with best avg reward.")
    return {"id": ids[best_idx], "document": docs[best_idx]}


if __name__ == "__main__":
    # Simulate a query and update flow
    query = "final chapter 1"
    suggestion = pick_best_version(query)
    if suggestion:
        print("Suggested Version ID:", suggestion["id"])
        print("---\n", suggestion["document"][:300])

        # Log full suggestion to file
        filename = timestamped_filename("version_pick")
        save_text_to_file(suggestion["document"], filename, folder=OUTPUT_LOG_DIR)

        feedback = input("Was this version useful? (y/n): ").strip().lower()
        record_feedback(suggestion["id"], 1.0 if feedback == "y" else 0.0)
