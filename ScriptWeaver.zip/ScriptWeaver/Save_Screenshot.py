import os
from datetime import datetime

# Simple logging utility
LOG_FILE = "logs/system/log.txt"
os.makedirs(os.path.dirname(LOG_FILE), exist_ok=True)

def log_message(message, level="INFO"):
    timestamp = datetime.now().strftime("[%Y-%m-%d %H:%M:%S]")
    log_line = f"{timestamp} [{level}] {message}"
    print(log_line)
    with open(LOG_FILE, "a") as f:
        f.write(log_line + "\n")
        
        
# def log_message(message: str):
#     timestamp = datetime.now().strftime("[%Y-%m-%d %H:%M:%S]")
#     log_dir = "logs/system"
#     os.makedirs(log_dir, exist_ok=True)
#     log_file = os.path.join(log_dir, "log.txt")

#     full_message = f"{timestamp} {message}"
#     print(full_message)

#     with open(log_file, "a") as f:
#         f.write(full_message + "\n")



# Create timestamped filename with optional prefix
def timestamped_filename(prefix: str) -> str:
    timecode = datetime.now().strftime("%Y%m%d_%H%M%S")
    return f"{prefix}_{timecode}.txt"


# Save text content to a file in a given folder
def save_text_to_file(text: str, filename: str, folder: str = "logs"):
    os.makedirs(folder, exist_ok=True)
    filepath = os.path.join(folder, filename)
    with open(filepath, "w", encoding="utf-8") as f:
        f.write(text)
    log_message(f"Saved file: {filepath}")
