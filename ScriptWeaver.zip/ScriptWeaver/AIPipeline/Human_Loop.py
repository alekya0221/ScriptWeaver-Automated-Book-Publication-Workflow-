from Save_Screenshot import log_message

def get_final_edit(text):
    log_message("Starting human review session...", level="INFO")

    print("\n--- Reviewed Draft ---\n")
    print(text)
    print("\n----------------------")

    try:
        print("Would you like to make edits? (y/n): ", end="", flush=True)
        
        # Prompting user for edit choice.
# We use 'print(..., end="", flush=True)' to ensure the prompt is displayed immediately in the terminal.
# Without this flush, the prompt may be buffered and invisible—especially when stderr is redirected or piped,
# causing the script to appear "stuck" while it waits for input.
# This flush is a workaround to terminal output buffering, and was added after noticing that the prompt wasn't visible
# even though input() was blocking correctly.
# Why we did this: To hide noisy thread affinity warnings like: pthread_setaffinity_np failed for thread: ..., error code: #22, error msg: Invalid argument. Specify the number of threads explicitly so the affinity is not set.
#grep -v "pthread_setaffinity_np" Filters out (i.e. suppresses) any line that contains the string pthread_setaffinity_np. #The -v flag tells grep to invert the match — it hides matching lines instead of printing them.
# This command runs Interface.main and filters out noisy ONNX Runtime thread affinity errors:
# python -m Interface.main 2> >(grep -v "pthread_setaffinity_np")
        choice = input().strip().lower()
    except (KeyboardInterrupt, EOFError):
        log_message("Human input interrupted. Falling back to AI-reviewed version.", level="WARNING")
        return text, "AI"

    if choice == "y":
        print("\nEnter your edited version below. Type 'END' on a new line to finish.\n")
        lines = []
        try:
            while True:
                line = input()
                if line.strip() == "END":
                    break
                lines.append(line)
        except (KeyboardInterrupt, EOFError):
            log_message("Editing session interrupted. Returning original text.", level="WARNING")
            return text, "AI"

        edited_text = "\n".join(lines)
        log_message("User provided manual edits.", level="INFO")
        return edited_text, "human"
    
    log_message("User accepted the reviewed version without edits.", level="INFO")
    return text, "AI"

