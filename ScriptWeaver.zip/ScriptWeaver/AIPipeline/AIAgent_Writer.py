import os
from openai import OpenAI
from Save_Screenshot import log_message

client = OpenAI(api_key=os.getenv("OPENAI_API_KEY"))

def rewrite_section(text: str) -> str:
    log_message("Rewriting section...", level="INFO")

    try:
        response = client.chat.completions.create(
            model="gpt-4", 
            messages=[
                {
                    "role": "system",
                    "content": "You are a writing assistant. Improve clarity, sentence flow, and structure without changing meaning."
                },
                {
                    "role": "user",
                    "content": text
                }
            ],
            temperature=0.7,
            max_tokens=1200
        )
        rewritten = response.choices[0].message.content.strip()
        log_message("Section successfully rewritten by Writer Agent.", level="INFO")
        return rewritten

    except Exception as e:
        log_message(f"[OpenAI Exception] {e.__class__.__name__}: {e}", level="ERROR")
        return " Unable to rewrite section due to OpenAI API issue."
