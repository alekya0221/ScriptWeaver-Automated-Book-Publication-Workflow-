from Scraping.Scrape_Screenshot import scrape_chapter
from AI_Pipeline.AIAgent_Writer import rewrite_section
from AI_Pipeline.AIAgent_Reviewer import refine_draft
from AI_Pipeline.Human_Loop import get_final_edit
from Save_Screenshot import log_message
from .FinalSaver import save_final_version
import os

def run_workflow(url: str):
    log_message(" Starting the book processing workflow...")

    # Step 1: Scrape and screenshot
    chapter_text = scrape_chapter(url)
    log_message(" Content and screenshot fetched successfully.")

    # Step 2: AI assistant rewrites the section
    rewritten = rewrite_section(chapter_text)
    log_message(" Section rewritten using assistant logic.")

    # Step 3: Language checker refines it
    refined = refine_draft(rewritten)
    log_message(" Draft refined by language checker.")

    # Step 4: Human review and edit phase
    final_text, source = get_final_edit(refined)
    log_message(" Final version updated by user input.")

    # Step 5: Save with reproducible version ID
    chapter_num = 1  # later, extract from URL dynamically
    version_id = save_final_version(final_text, chapter_num=chapter_num, source=source)
    print(f"\n Final version saved with ID: {version_id}")

if __name__ == "__main__":
    os.environ["OPENAI_API_KEY"] = os.getenv("OPENAI_API_KEY") or "your-openai-key"
    test_url = "https://en.wikisource.org/wiki/The_Gates_of_Morning/Book_1/Chapter_1"
    run_workflow(test_url)
